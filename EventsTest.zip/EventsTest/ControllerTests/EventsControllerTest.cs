﻿using Xunit;
using Moq;
using Microsoft.EntityFrameworkCore;
using EventsPage.Data;
using EventsPage.Controllers;
using EventsPage.Models;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace EventsTest.ControllerTests
{
    public class EventsControllerTest
    {
        [Fact]
        public async Task Index_ReturnsAViewResult_WithAListOfEvents()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "IndexTestDb")
                .Options;

            // Insert seed data into the database using one instance of the context
            using (var context = new ApplicationDbContext(options))
            {
                context.Event.Add(new Event { id = 1, name = "Test One", date = "2022-01-01", description = "Test Description", location = "Test Location", type = "Test Type" });
                context.Event.Add(new Event { id = 2, name = "Test Two", date = "2022-01-02", description = "Test Description", location = "Test Location", type = "Test Type" });
                context.SaveChanges();
            }

            // Use a clean instance of the context to run the test
            using (var context = new ApplicationDbContext(options))
            {
                var controller = new EventsController(context);

                // Act
                var result = await controller.Index();

                // Assert
                var viewResult = Assert.IsType<ViewResult>(result);
                var model = Assert.IsAssignableFrom<List<Event>>(viewResult.ViewData.Model);
                Assert.Equal(2, model.Count);
            }
        }

        [Fact]
        public async Task Details_ReturnsViewResult_WithEvent()
        {
            // Arrange
            int testId = 1;
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "DetailsTestDb")
                .Options;

            // Insert seed data into the database using one instance of the context
            using (var context = new ApplicationDbContext(options))
            {
                context.Event.Add(new Event { id = 1, name = "Test One", date = "2022-01-01", description = "Test Description", location = "Test Location", type = "Test Type" });
                context.SaveChanges();
            }


            // Use a clean instance of the context to run the test
            using (var context = new ApplicationDbContext(options))
            {
                var controller = new EventsController(context);

                // Act
                var result = await controller.Details(testId);

                // Assert
                var viewResult = Assert.IsType<ViewResult>(result);
                var model = Assert.IsAssignableFrom<Event>(viewResult.ViewData.Model);
                Assert.Equal(testId, model.id);
            }
        }

    }
}

